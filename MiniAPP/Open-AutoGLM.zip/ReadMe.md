# 后端模板 #
有后端的示例代码

# 框架 #
- [ ] PySide6
- [x] PySide6 + QML
- [ ] kivy
- [ ] PyGame
- [ ] PySDL2

# 版本 #
- 1.2 基础版本

# 内部版本 #
- 2.2 <基础模板.当前代码>  修改了ID号
