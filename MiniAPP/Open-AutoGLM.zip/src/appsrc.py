#!/usr/bin/env python3
# -*- coding: utf-8 -*-
###----------1、文件说明----------###
'''
* 说明：python程序模板
* 时间：
* 文件：
* 作者：Smile
* 版本：
 - 1.0 -> 2025-08-26 : 基础代码
    SHA256: A9217830632A76F04651AD7B002EBE5F87646971AF3DE40F81B84F75D3204980
 - 1.1 -> 2025-09-10 ：添加日志loginfo 变量属性
    SHA256: FDA211586E05DD52DBB2C4EBDE0C2A8D97FE4966035C0BC52272779579796A9D
* 备注：
'''
###----------2、库导入----------###
import os, sys, io
import traceback
import shutil
import subprocess
import time

from PySide6.QtCore import QObject,Signal,Slot,Property,QThread
from loguru import logger as log

from phone_agent import PhoneAgent
from phone_agent.adb import ADBConnection, list_devices
from phone_agent.agent import AgentConfig
from phone_agent.config.apps import list_supported_apps
from phone_agent.model import ModelConfig


###----------3、参数配置----------###
class AutoGLM(QThread):

    def __init__(self):
        super(AutoGLM, self).__init__()
        self.baseUrl = ""

    def setDevice(self, ipport):
        self.device = ipport

    def checkADB(self):
        if shutil.which("adb") is None:
            return "ADB 没有安装"
        else:
            return True

    def checkConDevices(self):
        try:
            result = subprocess.run(
                ["adb", "devices"], capture_output=True, text=True, timeout=10
            )
            # print("\nresult\n", result)
            # print("\nstdout\n", result.stdout)
            # print("\nstderr\n", result.stderr)
            lines = result.stdout.strip().split("\n")
            # 过滤掉头部和空行，查找“设备”状态
            devices = [line for line in lines[1:] if line.strip() and "\tdevice" in line]
            # print(devices)

            if not devices:
                return "没有连接到设备"
            else:
                device_ids = [d.split("\t")[0] for d in devices]
                print(f"已连接 {len(devices)} 个设备: {', '.join(device_ids)}")
                return True

        except subprocess.TimeoutExpired:
            print("❌ FAILED")
            print("   Error: ADB command timed out.")
            all_passed = False
        except Exception as e:
            print("❌ FAILED")
            print(f"   Error: {e}")

    def checkADBKeyboard(self):
        try:
            result = subprocess.run(
                ["adb", "-s", self.device, "shell", "ime", "list"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            # log.warning(result.stdout)
            # log.warning(result.stderr)
            ime_list = result.stdout.strip()
            # log.info(ime_list)
            if "com.android.adbkeyboard/.AdbIME" in ime_list:
                return True
            else:
                log.error(ime_list)
                return "没有安装ADBKeyboard输入法"
        except:
            pass

    def check(self):
        '''检查各种连接'''
        ret = self.checkADB()
        log.info("main-->", "checkADB", ret)
        if ret == True:
            ret = self.checkConDevices()
            log.info("main-->", "checkConDevices", ret)
        else:
            return ret
        if ret == True:
            ret = self.checkADBKeyboard()
            log.info("main-->", "checkADBKeyboard", ret)
            return ret
        else:
            return ret

    def ADBConnection(self):
        '''连接ADB'''
        conn = ADBConnection()

        log.info(f"连接到设备 to {self.device}...")
        success, message = conn.connect(self.device)
        log.info("success", success)
        log.info("message", message)
        if success == True:
            return True
        else:
            log.error("错误信息", message)
            return False

    def config(self):
        # 创建配置
        self.model_config = ModelConfig(
            base_url=self.base_url,
            model_name=self.model_name,
            api_key=self.api_key,
        )

        self.agent_config = AgentConfig(
            max_steps=self.max_steps,
            device_id=self.device,
            verbose=self.verbose, # 详细的日志输出
            lang=self.lang,
        )

        # 创建 Agent
        self.agent = PhoneAgent(
            model_config=self.model_config,
            agent_config=self.agent_config,
        )

    def configParam(self, url, modelname, apikey, maxstep, verbose, lang):
        self.base_url = url
        self.model_name = modelname
        self.api_key = apikey
        self.max_steps = int(maxstep)
        self.verbose = verbose
        self.lang = lang

    def runAgent(self, task=""):
        log.info("开始运行手机Agent")

        # 运行提供的任务或进入交互模式
        if task:
            log.info(f"\n任务-->: {task}\n")
            result = self.agent.run(task)
            log.info(f"\n运行结果-->: {result}")
        else:
            # 互动模式
            log.info("\n进入互动模式。输入'quit'退出。\n")
            while True:
                try:
                    task = input("输入你的任务: ").strip()

                    if task.lower() in ("quit", "exit", "q"):
                        print("程序退出!")
                        break

                    if not task:
                        continue

                    print()
                    result = self.agent.run(task)
                    print(f"\nAgent运行结果: {result}\n")
                    self.agent.reset()

                except KeyboardInterrupt:
                    print("\n\n按键终止. 再见!")
                    break
                except Exception as e:
                    print(f"\n出错: {e}\n")

    def setRunCmd(self, cmd):
        self.runCmd = cmd

    def run(self):
        self.runAgent(self.runCmd)

###----------4、主体程序----------###
class Backend(QObject):
    '''
    后端控制程序
    '''
    def __init__(self):
        super().__init__()
        self._text = "PySide6 QML APP"
        self._loginfo = ''
        self.initAutoGLM()
        self.agent.setDevice("192.168.10.108:5555")

        log.add(
            self.showLog,
            format="{message}",
            colorize=True,
            level="DEBUG",
            filter=lambda record: record["extra"].get("name") == 'Agent',
        )

    def showLog(self, msg):
        print("showLog-->", msg)
        self.set_loginfo(msg)

    # <---------- text属性管理 ---------->
    textChanged = Signal(str)
    def get_text(self):
        return self._text
    def set_text(self, value):
        self._text = value
        self.textChanged.emit(value)  # 属性变化时发射信号
    text = Property(str, get_text, set_text, notify=textChanged)

    # <---------- 日志信息管理 ---------->
    loginfoChanged = Signal(str)
    def get_loginfo(self):
        return self._loginfo
    def set_loginfo(self, value):
        value = value.strip()
        self._loginfo += value + '\n'
        self.loginfoChanged.emit(value)  # 属性变化时发射信号
    loginfo = Property(str, get_loginfo, set_loginfo, notify=loginfoChanged)

    def initAutoGLM(self):
        '''初始化'''
        self.agent = AutoGLM()

    def runAutoGLM(self, cmd):
        self.agent.ADBConnection()
        ret = self.agent.check()
        log.info("check", ret)
        if ret == True:
            ret = self.agent.ADBConnection()
        else:
            return ret

        if ret == True:
            self.agent.config()
            self.agent.setRunCmd(cmd)
            self.agent.start()
            return True

    @Slot(str,str,str,str,str,str)
    def setAgentConfig(self, url, modelname, apikey, maxstep, verbose, lang):
        tmpio = io.StringIO()
        print("配置参数", url, modelname, apikey, maxstep, verbose, lang, file=tmpio)
        log.info(tmpio.getvalue())
        if verbose == "true":
            self.agent.configParam(url, modelname, apikey, maxstep, True, lang)
        else:
            self.agent.configParam(url, modelname, apikey, maxstep, False, lang)

    @Slot(str)
    def setDevice(self, sip):
        '''设置服务器的IP端口'''
        log.debug(sip)
        self.agent.setDevice(sip)

    @Slot(str)
    def runAgent(self, cmd):
        log.debug(f"QML says: {cmd}")
        ret = self.runAutoGLM(cmd)
        if ret != True:
            log.error(ret)

    # 槽：供QML调用的方法
    @Slot(str)
    def debug(self, msg):
        log.debug(f"QML msg: {msg}")
        self.initAutoGLM()

        try:
            import openai
            log.info(openai.VERSION)
            import phone_agent
        except:
            ret = traceback.format_exc()
            log.error(ret)

        os.chmod("bin/adb", 0o755)
        os.chmod("bin/fastboot", 0o755)
        os.chmod("bin/scrcpy_server", 0o755)
        cmd = "ls -alh bin"
        fd = os.popen(cmd)
        data = fd.read()
        log.info(data)

        adb_path = shutil.which("adb")
        log.info(os.environ.get("PATH"))
        log.info(adb_path)

        envpath = os.environ.get("PATH") + ":" + os.path.join(os.getcwd(), "bin")
        os.environ["PATH"] = envpath
        adb_path = shutil.which("adb")
        log.info(os.environ.get("PATH"))
        log.info(adb_path)

        ret = self.agent.check()
        print("check", ret)
        if ret == True:
            self.agent.config()
            self.agent.run("打开微信")

        # for path in os.environ("PATH"):
        #     log.info(path)

    # 槽：供QML调用的方法
    @Slot(str)
    def qmlCallback(self, message):
        log.debug(f"QML says: {message}")
